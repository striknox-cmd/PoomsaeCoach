package com.striknox.poomsaecoach

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App() } }
}

private val Ink = Color(0xFF090B0F); private val Panel = Color(0xFF151922)
private val Gold = Color(0xFFCFAF63); private val Green = Color(0xFF43D17A); private val Red = Color(0xFFFF6464)

@Composable fun App() {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Ink, surface = Panel)) {
        var selected by remember { mutableStateOf(taegeukForms.first()) }
        var mode by remember { mutableStateOf(AnalysisMode.LIVE) }
        var started by remember { mutableStateOf(false) }
        var completed by remember { mutableStateOf<List<StepResult>>(emptyList()) }
        var video by remember { mutableStateOf<Uri?>(null) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { video = it }
        Surface(Modifier.fillMaxSize()) { LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Header() }
            item { FormSelector(selected) { selected = it; completed = emptyList(); started = false } }
            item { ModeSwitch(mode) { mode = it; started = false } }
            item {
                AnalyzerCard(mode, video, started, onChooseVideo = { picker.launch("video/*") }, onStart = {
                    started = !started
                    if (started) completed = simulate(selected)
                })
            }
            item { ScoreCard(selected, completed) }
            items(completed) { ResultRow(it) }
            item { Text("Prototype scoring uses calibration rules. Replace DemoRules with coach-validated step templates before athlete assessment.", color=Color.Gray, style=MaterialTheme.typography.bodySmall) }
        }}
    }
}

@Composable private fun Header() { Column { Text("STRIKNOX", color=Gold, fontWeight=FontWeight.Black); Text("POOMSAE COACH", style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold); Text("Precision feedback • step by step", color=Color.LightGray) } }

@Composable private fun FormSelector(selected:PoomsaeForm, onSelect:(PoomsaeForm)->Unit) {
    var open by remember { mutableStateOf(false) }
    Column { Text("POOMSAE", color=Gold, style=MaterialTheme.typography.labelMedium); Box {
        OutlinedButton(onClick={open=true}, modifier=Modifier.fillMaxWidth()) { Text("${selected.name}  •  ${selected.steps} movements"); Spacer(Modifier.weight(1f)); Text("⌄") }
        DropdownMenu(open, {open=false}) { taegeukForms.forEach { DropdownMenuItem(text={Text(it.name)}, onClick={onSelect(it);open=false}) } }
    }}
}

@Composable private fun ModeSwitch(mode:AnalysisMode, onMode:(AnalysisMode)->Unit) { Row(Modifier.fillMaxWidth()) {
    AnalysisMode.entries.forEach { item -> FilterChip(selected=mode==item, onClick={onMode(item)}, label={Text(if(item==AnalysisMode.LIVE) "Live camera" else "Upload video")}, modifier=Modifier.weight(1f).padding(horizontal=4.dp)) }
} }

@Composable private fun AnalyzerCard(mode:AnalysisMode, video:Uri?, started:Boolean, onChooseVideo:()->Unit, onStart:()->Unit) {
    Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(20.dp)) { Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Box(Modifier.fillMaxWidth().aspectRatio(3f/4f).background(Color.Black, RoundedCornerShape(14.dp)), contentAlignment=Alignment.Center) {
            if (mode==AnalysisMode.LIVE) CameraPreview() else Text(video?.lastPathSegment ?: "Choose an athlete video", color=Color.LightGray)
            if(started) Box(Modifier.align(Alignment.TopStart).padding(12.dp).background(Red, RoundedCornerShape(8.dp)).padding(8.dp,4.dp)){Text("ANALYZING", fontWeight=FontWeight.Bold)}
        }
        if(mode==AnalysisMode.VIDEO) OutlinedButton(onClick=onChooseVideo, modifier=Modifier.fillMaxWidth()){Text("Choose video")}
        Button(onClick=onStart, enabled=mode==AnalysisMode.LIVE || video!=null, modifier=Modifier.fillMaxWidth()){Text(if(started) "Stop analysis" else "Start analysis")}
    }}
}

@Composable private fun CameraPreview() {
    val context=LocalContext.current
    val lifecycleOwner=LocalLifecycleOwner.current
    var allowed by remember { mutableStateOf(ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) }
    val request=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){allowed=it}
    LaunchedEffect(Unit){if(!allowed) request.launch(Manifest.permission.CAMERA)}
    if(!allowed) Text("Camera permission required") else AndroidView(factory={ctx-> PreviewView(ctx).also { view ->
        val provider=ProcessCameraProvider.getInstance(ctx); provider.addListener({ val p=provider.get(); val preview=Preview.Builder().build(); preview.surfaceProvider=view.surfaceProvider; p.unbindAll(); p.bindToLifecycle(lifecycleOwner,CameraSelector.DEFAULT_BACK_CAMERA,preview)},ContextCompat.getMainExecutor(ctx))
    }}, modifier=Modifier.fillMaxSize())
}

private fun simulate(form:PoomsaeForm)=DemoRules.forForm(form).map { rule ->
    val drift=Random.nextInt(-18,19); ScoringEngine.evaluate(rule, rule.joints.map { DetectedJoint(it.joint,it.targetAngle+drift, .92f) })
}

@Composable private fun ScoreCard(form:PoomsaeForm, results:List<StepResult>) { val passed=results.count{it.passed}; val score=if(results.isEmpty())0 else results.map{it.score}.average().toInt()
    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF202630))) { Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement=Arrangement.SpaceBetween) { Column{Text("OVERALL SCORE",color=Color.Gray);Text("$score%",style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Black,color=Gold)};Column(horizontalAlignment=Alignment.End){Text("SUCCESSFUL STEPS",color=Color.Gray);Text("$passed / ${form.steps}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)} } }
}
@Composable private fun ResultRow(r:StepResult){Card(colors=CardDefaults.cardColors(containerColor=Panel)){Column(Modifier.padding(14.dp)){Row{Text("${r.step}. ${r.title}",Modifier.weight(1f),fontWeight=FontWeight.Bold);Text("${r.score}%",color=if(r.passed)Green else Red)}; if(r.errors.isEmpty())Text("Correct technique",color=Green) else r.errors.take(2).forEach{Text("• $it",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)}}}}
