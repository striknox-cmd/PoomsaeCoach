# STRIKNOX Poomsae Coach — Android MVP

An Android Studio prototype for camera/video-based Taegeuk analysis. It includes:

- Taegeuk 1–8 selection and movement counts
- live CameraX preview and Android video picker
- confidence-weighted joint-angle scoring
- successful-step count, overall score, and error list
- a clean Jetpack Compose athlete-facing interface
- MediaPipe Tasks Vision dependency ready for Pose Landmarker integration

## Run

Open `PoomsaeCoach` in Android Studio (JDK 17), let Gradle sync, and run on a physical Android device. Camera permission is requested on first use.

## Current MVP boundary

The project intentionally uses `simulate()` to demonstrate the complete user journey. It does **not** claim competition-grade evaluation yet. Production use requires:

1. Add the MediaPipe `pose_landmarker_lite.task` model to `app/src/main/assets/`.
2. Feed CameraX `ImageAnalysis` frames and decoded uploaded-video frames into Pose Landmarker.
3. Convert landmarks to normalized joint angles, orientation, stance width/depth, balance, timing, and trajectory.
4. Replace `DemoRules` with a separately validated rule sequence for every movement of Taegeuk 1–8.
5. Calibrate thresholds using labelled recordings reviewed by certified World Taekwondo poomsae coaches.

The rule engine is already isolated so those validated templates can be added without rebuilding the UI.

## Recommended production scoring

- Stance accuracy: 30%
- Hand technique/chamber: 25%
- Balance and posture: 15%
- Direction and trajectory: 15%
- Timing and rhythm: 15%

Use confidence gating: a low-visibility joint should produce “reposition camera,” not a technical fault.
