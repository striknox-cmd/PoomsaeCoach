#!/usr/bin/env bash
# Adds camera permission to the generated Android manifest.
set -euo pipefail
M=android/app/src/main/AndroidManifest.xml
if ! grep -q 'android.permission.CAMERA' "$M"; then
  sed -i 's#</manifest>#    <uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n</manifest>#' "$M"
fi
echo "Camera permission added"
