#!/usr/bin/env bash
# Copies the pose-tracking engine and model into the app so it works offline.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p www/mediapipe
cp node_modules/@mediapipe/tasks-vision/vision_bundle.mjs www/mediapipe/vision_bundle.js
rm -rf www/mediapipe/wasm
cp -r node_modules/@mediapipe/tasks-vision/wasm www/mediapipe/wasm
if [ ! -f www/mediapipe/pose_landmarker_full.task ]; then
  curl -fL -o www/mediapipe/pose_landmarker_full.task \
    https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/1/pose_landmarker_full.task
fi
echo "Pose model and engine bundled into www/mediapipe"
