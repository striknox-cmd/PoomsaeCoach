# Poomsae Scorer for Android

Scores Taekwondo poomsae stances from the live camera or an uploaded video.
The pose model is bundled inside the APK, so scoring works offline.

## Option A: Build the APK on GitHub (no Android tools needed)

1. Create a free account at github.com and make a new repository.
2. Upload everything in this folder, including the hidden `.github` folder,
   to the `main` branch. (On a computer, drag the unzipped folder contents
   into "Add file > Upload files".)
3. Open the **Actions** tab. The "Build Android APK" job starts by itself
   and takes about 5–8 minutes. If it doesn't start, pick the job and tap
   **Run workflow**.
4. When it shows a green check, open the run and download
   **poomsae-scorer-apk** under Artifacts. Unzip it to get `app-debug.apk`.
5. Copy the APK to your phone, open it, and allow "Install unknown apps"
   when Android asks.

## Option B: Build on your own computer

Requires Node.js 20+, JDK 21, and Android Studio (with the Android SDK).

```bash
npm install
npm run assets        # bundles the pose model
npm run android:init  # creates the android/ project + camera permission
npm run sync
npm run apk
```

The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`.
You can also run `npx cap open android` and press Run in Android Studio.

After editing `www/index.html`, run `npm run sync` and build again.

## Publishing to Google Play

The debug APK is for testing and sharing directly. Play Store needs a signed
release build (`./gradlew bundleRelease` with your own signing key). You can
change the app ID in `capacitor.config.json` before your first release, and
replace the default icon with `npx @capacitor/assets generate`.
