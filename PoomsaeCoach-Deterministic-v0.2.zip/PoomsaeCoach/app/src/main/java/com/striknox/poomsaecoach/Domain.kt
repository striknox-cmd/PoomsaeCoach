package com.striknox.poomsaecoach

enum class AnalysisMode { LIVE, VIDEO }

data class PoomsaeForm(val id: Int, val name: String, val steps: Int)

val taegeukForms = listOf(
    PoomsaeForm(1, "Taegeuk Il Jang", 18), PoomsaeForm(2, "Taegeuk Ee Jang", 18),
    PoomsaeForm(3, "Taegeuk Sam Jang", 20), PoomsaeForm(4, "Taegeuk Sa Jang", 20),
    PoomsaeForm(5, "Taegeuk Oh Jang", 20), PoomsaeForm(6, "Taegeuk Yuk Jang", 19),
    PoomsaeForm(7, "Taegeuk Chil Jang", 25), PoomsaeForm(8, "Taegeuk Pal Jang", 24)
)

data class JointRule(val joint: String, val targetAngle: Float, val tolerance: Float)
data class StepRule(val number: Int, val title: String, val holdMs: Long, val joints: List<JointRule>)
data class DetectedJoint(val joint: String, val angle: Float, val confidence: Float)
data class StepResult(val step: Int, val title: String, val score: Int, val passed: Boolean, val errors: List<String>)

object ScoringEngine {
    fun evaluate(rule: StepRule, detected: List<DetectedJoint>): StepResult {
        val errors = mutableListOf<String>()
        var weighted = 0f
        var weights = 0f
        rule.joints.forEach { expected ->
            val actual = detected.firstOrNull { it.joint == expected.joint }
            if (actual == null || actual.confidence < .55f) errors += "${expected.joint}: move fully into camera view"
            else {
                val delta = kotlin.math.abs(actual.angle - expected.targetAngle)
                val jointScore = (100f * (1f - delta / (expected.tolerance * 2f))).coerceIn(0f, 100f)
                weighted += jointScore * actual.confidence; weights += actual.confidence
                if (delta > expected.tolerance) errors += "${expected.joint}: ${delta.toInt()}° outside target"
            }
        }
        val score = if (weights == 0f) 0 else (weighted / weights).toInt()
        return StepResult(rule.number, rule.title, score, score >= 80 && errors.isEmpty(), errors)
    }
}

object DemoRules {
    fun forForm(form: PoomsaeForm): List<StepRule> = (1..form.steps).map { n ->
        StepRule(n, if (n % 2 == 0) "Technique & transition" else "Stance & chamber", 650,
            listOf(JointRule("Front knee", 110f, 12f), JointRule("Rear knee", 165f, 10f), JointRule("Torso", 90f, 8f)))
    }
}
