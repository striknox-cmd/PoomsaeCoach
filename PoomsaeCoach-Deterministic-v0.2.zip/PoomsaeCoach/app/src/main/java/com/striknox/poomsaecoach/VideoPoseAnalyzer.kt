package com.striknox.poomsaecoach

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseDetectorOptionsBase
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import com.google.mlkit.vision.pose.PoseLandmark
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class AnalysisReport(
    val results: List<StepResult>,
    val sampledFrames: Int,
    val usableFrames: Int,
    val rejected: Boolean,
    val message: String
)

/**
 * Deterministic, offline frame sampler. The same file produces the same timestamps and scores.
 * Scores are biomechanical screening metrics; form-specific templates still require coach sign-off.
 */
class VideoPoseAnalyzer(private val context: Context) {
    private val options: PoseDetectorOptionsBase = PoseDetectorOptions.Builder()
        .setDetectorMode(PoseDetectorOptions.SINGLE_IMAGE_MODE)
        .build()
    private val detector = PoseDetection.getClient(options)

    suspend fun analyze(uri: Uri, form: PoomsaeForm): AnalysisReport = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (durationMs < 2_000L) return@withContext AnalysisReport(emptyList(), 0, 0, true, "Video is too short")

            // Three fixed observations per movement, centered inside equal time windows.
            val sampleCount = min(form.steps * 3, 72)
            val poses = mutableListOf<Pose>()
            repeat(sampleCount) { index ->
                val timestampUs = ((index + 0.5) * durationMs * 1000.0 / sampleCount).toLong()
                val bitmap: Bitmap? = retriever.getFrameAtTime(timestampUs, MediaMetadataRetriever.OPTION_CLOSEST)
                if (bitmap != null) {
                    val pose = detector.process(InputImage.fromBitmap(bitmap, 0)).await()
                    if (visibility(pose) >= MIN_VISIBILITY) poses += pose
                    if (!bitmap.isRecycled) bitmap.recycle()
                }
            }

            if (poses.size < max(6, sampleCount / 3)) {
                return@withContext AnalysisReport(emptyList(), sampleCount, poses.size, true,
                    "Full body was not visible reliably. Use a fixed camera and keep head, hands and feet in frame.")
            }

            val results = (0 until form.steps).map { stepIndex ->
                val start = stepIndex * poses.size / form.steps
                val end = max(start + 1, (stepIndex + 1) * poses.size / form.steps)
                scoreWindow(stepIndex + 1, poses.subList(start, min(end, poses.size)))
            }
            AnalysisReport(results, sampleCount, poses.size, false, "Deterministic pose screening complete")
        } finally {
            retriever.release()
        }
    }

    private fun scoreWindow(step: Int, poses: List<Pose>): StepResult {
        val postureScores = poses.mapNotNull { p ->
            val ls = p.getPoseLandmark(PoseLandmark.LEFT_SHOULDER)
            val rs = p.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER)
            val lh = p.getPoseLandmark(PoseLandmark.LEFT_HIP)
            val rh = p.getPoseLandmark(PoseLandmark.RIGHT_HIP)
            val lk = p.getPoseLandmark(PoseLandmark.LEFT_KNEE)
            val rk = p.getPoseLandmark(PoseLandmark.RIGHT_KNEE)
            val la = p.getPoseLandmark(PoseLandmark.LEFT_ANKLE)
            val ra = p.getPoseLandmark(PoseLandmark.RIGHT_ANKLE)
            if (listOf(ls,rs,lh,rh,lk,rk,la,ra).any { it == null }) null else {
                val leftKnee = angle(lh!!, lk!!, la!!)
                val rightKnee = angle(rh!!, rk!!, ra!!)
                val shoulderTilt = lineTilt(ls!!, rs!!)
                val hipTilt = lineTilt(lh, rh)
                val torsoPenalty = (shoulderTilt + hipTilt).coerceAtMost(30f)
                val stancePenalty = if (min(leftKnee, rightKnee) > 174f) 18f else 0f
                (100f - torsoPenalty * 1.8f - stancePenalty).coerceIn(0f, 100f)
            }
        }
        val score = if (postureScores.isEmpty()) 0 else postureScores.average().toInt()
        val errors = mutableListOf<String>()
        if (score < 80) errors += "Posture, balance or stance alignment requires review"
        if (poses.size < 2) errors += "Movement was visible in too few frames"
        return StepResult(step, "Movement $step", score, score >= 80 && errors.isEmpty(), errors)
    }

    private fun visibility(pose: Pose): Float {
        val required = intArrayOf(PoseLandmark.NOSE, PoseLandmark.LEFT_WRIST, PoseLandmark.RIGHT_WRIST,
            PoseLandmark.LEFT_ANKLE, PoseLandmark.RIGHT_ANKLE)
        return required.mapNotNull { pose.getPoseLandmark(it)?.inFrameLikelihood }.average().toFloat()
    }

    private fun angle(a: PoseLandmark, b: PoseLandmark, c: PoseLandmark): Float {
        val abx=a.position.x-b.position.x; val aby=a.position.y-b.position.y
        val cbx=c.position.x-b.position.x; val cby=c.position.y-b.position.y
        val denominator=sqrt((abx*abx+aby*aby)*(cbx*cbx+cby*cby)).coerceAtLeast(.0001f)
        return Math.toDegrees(acos(((abx*cbx+aby*cby)/denominator).coerceIn(-1f,1f)).toDouble()).toFloat()
    }

    private fun lineTilt(a: PoseLandmark, b: PoseLandmark): Float {
        val dx=abs(b.position.x-a.position.x).coerceAtLeast(.0001f)
        return Math.toDegrees(kotlin.math.atan2(abs(b.position.y-a.position.y),dx).toDouble()).toFloat()
    }

    companion object { private const val MIN_VISIBILITY = .55f }
}
