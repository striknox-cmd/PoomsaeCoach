# STRIKNOX Poomsae Coach — Deterministic Pose Prototype v0.2

An Android Studio prototype for camera/video-based Taegeuk analysis. It includes:

- Taegeuk 1–8 selection and movement counts
- live CameraX preview and Android video picker
- confidence-weighted joint-angle scoring
- successful-step count, overall score, and error list
- a clean Jetpack Compose athlete-facing interface
- real on-device ML Kit body-landmark detection for uploaded videos
- fixed timestamp sampling: the same video follows the same scoring path
- safe rejection when head, hands, or feet are not visible reliably
- no random values or simulated scoring

## Run

Open `PoomsaeCoach` in Android Studio (JDK 17), let Gradle sync, and run on a physical Android device. Camera permission is requested on first use.

## Current validation boundary

This version performs real deterministic biomechanical screening. It does **not** claim certified World Taekwondo judging. Production competition use still requires:

1. Certified coach-authored rule sequence for every movement of Taegeuk 1–8.
2. Labelled correct/incorrect recordings for threshold calibration.
3. Two-camera calibration for movements with self-occluded limbs.
4. Independent validation, audit logs, judge override, and appeal workflow.
5. Live CameraX `ImageAnalysis` integration; live scoring is deliberately disabled until calibrated.

`VideoPoseAnalyzer` isolates the detector and deterministic scoring path so validated movement templates can replace the generic posture screen without rebuilding the UI.

## Repeatability

For each selected form, the analyzer samples up to 72 fixed timestamps, rejects frames without sufficient full-body visibility, groups usable observations into the official movement count, and applies fixed calculations. There is no `Random` or `simulate()` path.

## Recommended production scoring

- Stance accuracy: 30%
- Hand technique/chamber: 25%
- Balance and posture: 15%
- Direction and trajectory: 15%
- Timing and rhythm: 15%

Use confidence gating: a low-visibility joint should produce “reposition camera,” not a technical fault.
